
const {handler}=require("./index");
handler({"action":"create"});



